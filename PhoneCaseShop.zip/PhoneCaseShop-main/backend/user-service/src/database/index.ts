import User, { IUser } from "./models/UserModel";
import { connectDB } from "./connection";

export { User, IUser, connectDB };